# HTML 前端技术方案

## 1. 技术目标

第一阶段采用纯前端架构：

- HTML。
- CSS。
- 原生 JavaScript。
- JSON 数据文件。
- localStorage 或 IndexedDB。

不要求 Node.js，不要求后端，不要求数据库服务器。

## 2. 推荐目录结构

```text
project/
├─ index.html
├─ pages/
│  ├─ library.html
│  ├─ card.html
│  ├─ draw.html
│  ├─ spreads.html
│  ├─ rules.html
│  ├─ history.html
│  └─ learning.html
├─ assets/
│  ├─ css/
│  │  ├─ base.css
│  │  ├─ components.css
│  │  └─ responsive.css
│  ├─ js/
│  │  ├─ app.js
│  │  ├─ router.js
│  │  ├─ cards.js
│  │  ├─ draw.js
│  │  ├─ storage.js
│  │  └─ search.js
│  ├─ images/
│  │  └─ decks/
│  │     ├─ rws1909/
│  │     ├─ marseille/
│  │     └─ sola-busca/
│  └─ icons/
├─ data/
│  ├─ decks.json
│  ├─ cards-rws1909.json
│  ├─ cards-marseille.json
│  ├─ cards-sola-busca.json
│  ├─ spreads.json
│  └─ rules.json
└─ docs/
```

## 3. 页面实现方式

### 方案 A：多 HTML 页面

优点：

- 结构直观。
- 不依赖路由库。
- 容易单独修改。

缺点：

- 公共头部和底部需要重复维护。

适合最初 Demo。

### 方案 B：单页应用式 HTML

一个 `index.html`，通过 JavaScript 切换不同视图。

优点：

- 体验连贯。
- 适合抽牌动画和状态保存。
- 方便部署为 PWA。

缺点：

- JavaScript 结构需要更规范。

正式版本推荐方案 B，但仍坚持原生 JavaScript，不必立刻引入 React。

## 4. 数据加载

牌义内容放在 JSON 中，不写死在 HTML。

页面启动后：

1. 加载牌组列表。
2. 根据用户选择加载对应牌组数据。
3. 生成牌库卡片。
4. 点击后读取对应牌的数据。

注意：直接双击本地 HTML 时，部分浏览器可能限制 `fetch()` 读取本地 JSON。

解决方案：

- Demo 阶段可将 JSON 作为 JS 常量引入。
- 或使用一个极简本地服务器。
- 正式部署到静态托管后使用 JSON 文件。

## 5. 本地存储

### localStorage

适合：

- 设置。
- 收藏。
- 少量历史记录。

### IndexedDB

适合：

- 大量历史记录。
- 自定义牌阵。
- 学习进度。
- 图片缓存。

MVP 可以先用 localStorage，后续迁移到 IndexedDB。

## 6. 图片处理

建议每张牌提供：

- 原始图。
- 中等尺寸 WebP。
- 缩略图 WebP。

命名统一使用稳定 ID，例如：

```text
major-00-fool.webp
major-01-magician.webp
cups-01-ace.webp
cups-11-page.webp
```

不建议把中文牌名直接作为文件名，以免部署环境出现编码问题。

## 7. 响应式设计

断点建议：

- 小于 480px：手机。
- 481 至 768px：大屏手机和小平板。
- 769 至 1200px：平板和电脑。
- 大于 1200px：宽屏。

手机端优先：

- 底部导航。
- 单列详情。
- 牌库两列卡片。
- 抽牌区横向滚动或自适应缩放。

## 8. 性能要求

- 首页首屏尽量小于 1MB。
- 不一次加载所有高清牌面。
- 使用懒加载。
- 缩略图和详情图分离。
- 搜索索引在本地建立。
- 动画尊重 `prefers-reduced-motion`。

## 9. 部署方式

可以部署到：

- GitHub Pages。
- Cloudflare Pages。
- Netlify。
- Vercel 静态站点。
- 国内静态对象存储。

由于没有后端，部署成本接近零。

## 10. 后续可升级能力

- PWA 离线安装。
- Service Worker 缓存牌面。
- 多语言。
- 云同步。
- 用户自定义牌义。
- 主题皮肤。
- 数据包导入导出。

## 11. 安全与隐私

- 问题和记录默认只存在用户本机。
- 不自动上传用户问题。
- 不嵌入不必要的第三方统计脚本。
- 如加入统计，需匿名化并明确说明。
